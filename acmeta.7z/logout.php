<?php
require("includes/killSession.php");
?>